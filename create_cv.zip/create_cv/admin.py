from django.contrib import admin
from .models import *
admin.site.register(Diploma)
admin.site.register(Competence)
admin.site.register(Experience)
admin.site.register(Loisir)

admin.site.register(Cvmodel)
admin.site.register(CvImg)
admin.site.register(CVFolder)
admin.site.register(Cvsetting)
# Register your models here.
