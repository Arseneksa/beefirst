from django.apps import AppConfig


class CreateCvConfig(AppConfig):
    name = 'create_cv'
