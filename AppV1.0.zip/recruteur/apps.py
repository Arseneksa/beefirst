from django.apps import AppConfig


class RecruteurConfig(AppConfig):
    name = 'recruteur'
